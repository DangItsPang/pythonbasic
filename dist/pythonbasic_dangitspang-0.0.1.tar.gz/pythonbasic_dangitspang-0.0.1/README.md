# Example Package

Type in Python, get TI-Basic back!

Check out the Github page for more info. Enjoy!
https://github.com/DangItsPang/pythonbasic